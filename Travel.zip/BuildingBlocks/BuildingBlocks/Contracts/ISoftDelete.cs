﻿namespace BuildingBlocks.Contracts
{
    public interface ISoftDelete
    {
    }
}

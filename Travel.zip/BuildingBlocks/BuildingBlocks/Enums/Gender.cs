﻿using System.ComponentModel;

namespace BuildingBlocks.Enums;

public enum Gender
{
    [Description("مرد")]
    Male = 1,
    [Description("زن")]
    Female = 2
}

﻿namespace WalletPayment.Domain.Entities.Enums;

public enum TransactionDirection
{
    In = 1,   // واریز
    Out = 2   // برداشت
}
﻿namespace WalletPayment.Domain.Entities.Enums;
public enum SnapshotType
{
    Daily = 1,
    Weekly = 2,
    Monthly = 3,
    Manual = 4
}

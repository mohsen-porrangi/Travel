﻿namespace UserManagement.API.Endpoints.RoleManagement.Role.DeleteRole;

public record DeleteRoleCommand(int Id) : ICommand;
